from django.db import models

# creating requestaccess model with 2 fields
class Requestaccess(models.Model):
    email = models.CharField(max_length=50)
    skey = models.CharField(max_length=8)

class abc(models.Model):
    name = models.CharField(max_length=12)
    
