from django.shortcuts import render, redirect
from django.http import HttpResponse

# django module for messages
from django.contrib import messages

# django builtin models for user registration and authentication
from django.contrib.auth.models import User, auth

# django module for sending email
from django.core.mail import send_mail

# django model for requestaccess
from .models import Requestaccess as r

# python maodule for generating random numbers
import random

def requestaccess(request):
    if request.method == 'POST':
        email = request.POST['email']
        if r.objects.filter(email=email).exists():
            messages.warning(request, "Email already has access, Try Registering")
            return redirect('register')
        elif User.objects.filter(email=email).exists():
            messages.warning(request, "Account Exists, Try Logging In")
            return redirect('login')
        else:
            # list for holding 10 secret keys
            l = ['A00@v99$','E14!w79^','I96#x20~','O07@y11$','U29`z09+',
            'V99-a00=','W97^e41!','X02~i69#','Y11+o70`','Z90=u92-']
            # using random module to select one key out of 10 randomly
            i = random.randint(0,10)
            skey = l[i]
            # saving the requestaccess object in the db
            u = r.objects.create(email = email, skey = skey)
            u.save()
            # message to the user notifying successful save on db
            messages.success(request, "Request Sent Successfully")
            # send email to grant access, email contains a secret key which should be used while registering
            # message title
            msg1 = 'GyStaQ Classifier'
            # message body
            msg2 = 'Welcome '+email+' we have recieved your request for access and we are pleased'+' to inform you that you have been granted access.\nKindly use the secret key to register'+'\n\nSecret Key : '+skey
            # email sending host, remember to add the EMAIL related settings in settings.py of GyStaQ
            host = 'gystaq@gmail.com'
            # reciever email
            rec = email
            # send email 
            send_mail(msg1,msg2,host,[rec])
            return redirect('register')
    else:
        # GET request
        return render(request, 'accounts/requestaccess.html')    


def register(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        email = request.POST['email']
        skey = request.POST['skey']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        
        if password1 == password2:
            if User.objects.filter(username=username).exists():
                messages.warning(request, "Username Taken")
                return redirect('register')
            elif User.objects.filter(email=email).exists():
                messages.warning(request, "Email Taken")
                return redirect('register')
            else:
                if r.objects.filter(email=email).exists():
                    # email has been granted access
                    if r.objects.filter(skey=skey).exists():
                        # checking if secret key entered by the user matches with the secret key sent to the user
                        # save the user details in the db
                        user = User.objects.create_user(first_name = first_name, last_name = last_name, username = username, email = email, password = password2)
                        user.save()
                        # delete the data requestaccess object
                        dele = r.objects.all().delete()
                        # message to the user notifying successful save on db
                        messages.success(request, "User Created Successfully")
                        # send email after user is registered succcessfully
                        # message title
                        msg1 = 'Welcome to GyStaQ Classifier'
                        # message body
                        msg2 = 'Welcome '+first_name+' '+last_name+' \nWelcome to GyStaQ!!. We are glad you are here, we hope you enjoy using GyStaQ Classifier.'
                        # email sending host, remember to add the EMAIL related settings in settings.py of GyStaQ
                        host = 'gystaq@gmail.com'
                        # reciever email
                        rec = email
                        # send email 
                        send_mail(msg1,msg2,host,[rec])
                        return redirect('login')
                    else:
                        messages.error(request, "Invalid Secret Key, Try Again")
                        return redirect('register')
                else:
                    messages.error(request, "Email has no Access, Request Access")
                    return redirect('requestaccess')
        else:
            messages.error(request, "Password Not Matching")
            return redirect('register')
    else:
        # GET request
        return render(request, 'accounts/register.html')


def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        # user authentication
        user = auth.authenticate(username = username, password = password)

        if user is not None:
            # successful authentication
            auth.login(request, user)
            return redirect('/')
        else:
            messages.error(request, "Invalid Credentials")
            return redirect('login')
    else:
        # GET request
        return render(request, 'accounts/login.html')


def logout(request):
    # logout the user
    auth.logout(request)
    return redirect('/')