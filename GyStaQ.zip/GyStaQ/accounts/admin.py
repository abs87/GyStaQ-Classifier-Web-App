from django.contrib import admin
from . import models

# naming format should be modelnameAdmin(admin.ModelAdmin)
class RequestaccessAdmin(admin.ModelAdmin):
    list_display = ('email', 'skey')

# registering the model into the django admin panel
admin.site.register(models.Requestaccess, RequestaccessAdmin)
