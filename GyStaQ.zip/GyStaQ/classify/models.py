from django.db import models

# creating a model for classify with 12 fields
class Classify(models.Model):
    user = models.CharField(max_length=50)
    date = models.DateField()
    time = models.TimeField()
    ra = models.FloatField()
    dec = models.FloatField()
    u = models.FloatField()
    g = models.FloatField()
    r = models.FloatField()
    i = models.FloatField()
    z = models.FloatField()
    redshift = models.FloatField()
    objclass = models.CharField(max_length=20)

