from django.contrib import admin
from . import models

# naming format should be modelnameAdmin(admin.ModelAdmin)
class ClassifyAdmin(admin.ModelAdmin):
    list_display = ('user','date','time','ra', 'dec','u','g','r','i','z','redshift')

# registering the classify model to django admin panel
admin.site.register(models.Classify, ClassifyAdmin)

