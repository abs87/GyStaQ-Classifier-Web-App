from django.shortcuts import render
from django.http import HttpResponse

# django builtin models for user registration and authentication
from django.contrib.auth.models import User, auth

# django model for classify
from .models import Classify

# python module for datetime related operations
from datetime import datetime
# pandas library
import pandas as pd
# pickle module to open pickled xgboost model and perform classification
import pickle
# xgbclassifier 
from xgboost import XGBClassifier

def classify(request):
    user = request.user
    if user.is_authenticated:
        return render(request, 'classify/classify.html')
    else:
        return render(request, 'accounts/login.html')

def history(request):
    user = request.user
    if user.is_authenticated:
        if user.username == 'admin':
            # all rows of classify
            rows = Classify.objects.all()
            return render(request, 'classify/history.html',{'rows':rows})
        else:
            # rows only belonging to user
            rows = Classify.objects.all().filter(user=request.user)
            return render(request, 'classify/history.html',{'rows':rows})
    else:
        return render(request, 'accounts/login.html')
   
def result(request):
    user = request.user
    if user.is_authenticated:
        ra = request.POST['ra']
        dec = request.POST['dec']
        u = request.POST['u']
        g = request.POST['g']
        r = request.POST['r']
        i = request.POST['i']
        z = request.POST['z']
        redshift = request.POST['redshift']
        us = request.user
        date = datetime.now().date()
        time = datetime.now().time()
        
        # converting data to pandas series before giving it as an input to the pickled xgboost model
        s1 = pd.Series([float(ra)], name='ra')
        s2 = pd.Series([float(dec)], name='dec')
        s3 = pd.Series([float(u)], name='u')
        s4 = pd.Series([float(g)], name='g')
        s5 = pd.Series([float(r)], name='r')
        s6 = pd.Series([float(i)], name='i')
        s7 = pd.Series([float(z)], name='z')
        s8 = pd.Series([float(redshift)], name='redshift')
        inp = pd.concat([s1, s2, s3, s4, s5, s6, s7, s8], axis=1)
        
        # change the path of the pickled file accordingly
        f = open('/home/abs/Desktop/dev/django_3/GyStaQ/classify/pickled_model.pkl','rb')
        m = pickle.load(f)
        # performing classification
        resu = m.predict(inp)
        res = int(resu)
        f.close()
        
        # during creating the model data was normalized and now it is reverted back
        if res == 0:
            c = 'GALAXY'
        elif res == 1:
            c = 'QUASAR'
        else:
            c = 'STAR'
        
        # saving the classification data on the db
        cl = Classify.objects.create(user=us, date=date,time=time, ra=ra, dec=dec, u=u, g=g, r=r, i=i, z=z, redshift=redshift,objclass=c)
        # returning a dictionary to result.html for displaying
        return render(request,'classify/result.html',{'c': c, 'ra': ra, 'dec': dec, 'u': u, 'g': g, 'r': r, 'i': i, 'z': z, 'redshift': redshift,})
    else:
        return render(request, 'accounts/login.html')
