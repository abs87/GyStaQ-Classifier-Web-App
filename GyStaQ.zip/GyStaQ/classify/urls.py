from django.urls import path
from . import views

# importing view function of accounts app, code reusability
from accounts import views as v

# url routing for classify
urlpatterns = [
    path('', views.classify),
    path('result', views.result),
    path('login', v.login),
    path('logout', v.logout),
    path('history', views.history),
]