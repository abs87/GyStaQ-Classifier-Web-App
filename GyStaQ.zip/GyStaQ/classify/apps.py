from django.apps import AppConfig


class ClassifyConfig(AppConfig):
    name = 'classify'
