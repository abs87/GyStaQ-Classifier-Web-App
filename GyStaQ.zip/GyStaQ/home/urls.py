from django.urls import path
from . import views

# url routing for home
urlpatterns = [
    path('', views.home)
]
